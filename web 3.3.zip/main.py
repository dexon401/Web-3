from flask import Flask
from data import db_session
from data.users import User

app = Flask(__name__)
app.config["SECRET_KEY"] = "yandexlyceum_secret_key"


def main():
    db_session.global_init("db/mars_explorer.db")
    
    db_sess = db_session.create_session()
    
    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = "captain"
    user.speciality = "recearch engineer"
    user.address = "module_1"
    user.email = "scott_chief@mars.org"
    db_sess.add(user)
    
    user2 = User()
    user2.surname = "Smith"
    user2.name = "John"
    user2.age = 25
    user2.position = "engineer"
    user2.speciality = "mechanical engineer"
    user2.address = "module_2"
    user2.email = "john_smith@mars.org"
    db_sess.add(user2)
    
    user3 = User()
    user3.surname = "Johnson"
    user3.name = "Jane"
    user3.age = 28
    user3.position = "scientist"
    user3.speciality = "biologist"
    user3.address = "module_3"
    user3.email = "jane_johnson@mars.org"
    db_sess.add(user3)
    
    user4 = User()
    user4.surname = "Brown"
    user4.name = "Bob"
    user4.age = 30
    user4.position = "pilot"
    user4.speciality = "aeronautics"
    user4.address = "module_4"
    user4.email = "bob_brown@mars.org"
    db_sess.add(user4)
    
    db_sess.commit()
    
    # app.run()


if __name__ == "__main__":
    main()
